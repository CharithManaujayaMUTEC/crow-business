<?php

namespace App\Filament\Resources;

use App\Models\Payroll;
use Filament\Resources\Resource;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;

class PayrollResource extends Resource
{
    protected static ?string $model = Payroll::class;
    protected static ?string $navigationLabel = 'Payroll';
    protected static ?string $modelLabel = 'Payroll';
    protected static ?string $pluralModelLabel = 'Payroll';

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Select::make('employee_id')->relationship('employee','name')->searchable()->preload()->required(),
            TextInput::make('period')->placeholder('2026-08')->required(),
            DatePicker::make('payment_date'),
            TextInput::make('basic_salary')->numeric()->required(),
            TextInput::make('allowance')->numeric()->default(0),
            TextInput::make('deduction')->numeric()->default(0),
            TextInput::make('net_salary')->numeric()->required(),
            Select::make('status')->options(['pending'=>'Pending','paid'=>'Paid'])->default('pending'),
            Textarea::make('notes')->columnSpanFull()
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('employee.name')->searchable(),
            TextColumn::make('period')->sortable(),
            TextColumn::make('net_salary')->money('LKR'),
            TextColumn::make('payment_date')->date(),
            TextColumn::make('status')->badge()
        ])->recordActions([
            Action::make('edit')
                ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
        ])->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPayroll::route('/'),
            'create' => Pages\CreatePayroll::route('/create'),
            'edit' => Pages\EditPayroll::route('/{record}/edit'),
        ];
    }
}
