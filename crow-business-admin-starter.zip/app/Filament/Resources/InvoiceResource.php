<?php

namespace App\Filament\Resources;

use App\Models\Invoice;
use Filament\Resources\Resource;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;

class InvoiceResource extends Resource
{
    protected static ?string $model = Invoice::class;
    protected static ?string $navigationLabel = 'Invoices';
    protected static ?string $modelLabel = 'Invoice';
    protected static ?string $pluralModelLabel = 'Invoices';

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Select::make('customer_id')->relationship('customer','name')->searchable()->preload()->required(),
            Select::make('quotation_id')->relationship('quotation','number')->searchable(),
            Hidden::make('number'),
            Select::make('status')->options(['issued'=>'Issued','partially_paid'=>'Partially Paid','paid'=>'Paid','overdue'=>'Overdue','cancelled'=>'Cancelled'])->default('issued')->required(),
            DatePicker::make('issued_at')->default(now()),
            DatePicker::make('due_at'),
            TextInput::make('subtotal')->numeric()->default(0),
            TextInput::make('discount')->numeric()->default(0),
            TextInput::make('tax')->numeric()->default(0),
            TextInput::make('total')->numeric()->default(0)->required(),
            TextInput::make('balance')->numeric()->default(0)->required(),
            Textarea::make('notes')->columnSpanFull()
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('number')->searchable()->sortable(),
            TextColumn::make('customer.name')->searchable(),
            TextColumn::make('status')->badge(),
            TextColumn::make('total')->money('LKR'),
            TextColumn::make('balance')->money('LKR'),
            TextColumn::make('due_at')->date()
        ])->recordActions([
            Action::make('edit')
                ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
        ])->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListInvoice::route('/'),
            'create' => Pages\CreateInvoice::route('/create'),
            'edit' => Pages\EditInvoice::route('/{record}/edit'),
        ];
    }
}
