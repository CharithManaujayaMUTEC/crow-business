<?php

namespace App\Services;

use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Quotation;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Storage;

class PdfDocumentService
{
    public function quotation(Quotation $quotation): string
    {
        $quotation->loadMissing(['customer', 'items']);

        return $this->store(
            Pdf::loadView('pdf.quotation', compact('quotation')),
            'quotations',
            $quotation->number . '.pdf'
        );
    }

    public function invoice(Invoice $invoice): string
    {
        $invoice->loadMissing(['customer', 'quotation', 'items', 'payments']);

        return $this->store(
            Pdf::loadView('pdf.invoice', compact('invoice')),
            'invoices',
            $invoice->number . '.pdf'
        );
    }

    public function paymentSlip(Payment $payment): string
    {
        $payment->loadMissing(['customer', 'invoice']);

        $filename = 'PAY-' . $payment->id . '-' . now()->format('YmdHis') . '.pdf';

        return $this->store(
            Pdf::loadView('pdf.payment-slip', compact('payment')),
            'payment-slips',
            $filename
        );
    }

    private function store($pdf, string $directory, string $filename): string
    {
        $path = $directory . '/' . $filename;

        Storage::disk('public')->put($path, $pdf->output());

        return $path;
    }
}
