<?php

namespace App\Filament\Resources;

use App\Models\RecurringService;
use Filament\Resources\Resource;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;

class RecurringServiceResource extends Resource
{
    protected static ?string $model = RecurringService::class;
    protected static ?string $navigationLabel = 'Recurring Services';
    protected static ?string $modelLabel = 'Recurring Service';
    protected static ?string $pluralModelLabel = 'Recurring Services';

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Select::make('customer_id')->relationship('customer','name')->searchable()->preload()->required(),
            Select::make('service_id')->relationship('service','name')->searchable()->preload()->required(),
            TextInput::make('amount')->numeric()->prefix('LKR')->required(),
            Select::make('frequency')->options(['monthly'=>'Monthly','yearly'=>'Yearly'])->default('monthly')->required(),
            TextInput::make('billing_day')->numeric()->minValue(1)->maxValue(28)->default(1)->required(),
            DatePicker::make('start_date')->required(),
            DatePicker::make('next_billing_date')->required(),
            Select::make('status')->options(['active'=>'Active','paused'=>'Paused','cancelled'=>'Cancelled'])->default('active'),
            Toggle::make('auto_invoice')->default(true),
            TextInput::make('reminder_days')->helperText('Comma separated, e.g. 7,3,1')->default('7,3,1')
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('customer.name')->searchable(),
            TextColumn::make('service.name')->searchable(),
            TextColumn::make('amount')->money('LKR'),
            TextColumn::make('frequency'),
            TextColumn::make('next_billing_date')->date(),
            TextColumn::make('status')->badge()
        ])->recordActions([
            Action::make('edit')
                ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
        ])->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListRecurringService::route('/'),
            'create' => Pages\CreateRecurringService::route('/create'),
            'edit' => Pages\EditRecurringService::route('/{record}/edit'),
        ];
    }
}
