<?php

namespace App\Filament\Resources;

use App\Models\Payment;
use Filament\Resources\Resource;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;

class PaymentResource extends Resource
{
    protected static ?string $model = Payment::class;
    protected static ?string $navigationLabel = 'Payments';
    protected static ?string $modelLabel = 'Payment';
    protected static ?string $pluralModelLabel = 'Payments';

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Select::make('invoice_id')->relationship('invoice','number')->searchable()->preload()->required()->live(),
            Select::make('customer_id')->relationship('customer','name')->searchable()->preload()->required(),
            TextInput::make('amount')->numeric()->prefix('LKR')->required(),
            DatePicker::make('paid_at')->default(now())->required(),
            Select::make('method')->options(['cash'=>'Cash','bank'=>'Bank Transfer','card'=>'Card','online'=>'Online']),
            TextInput::make('reference'),
            Textarea::make('notes')->columnSpanFull()
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('invoice.number')->searchable(),
            TextColumn::make('customer.name')->searchable(),
            TextColumn::make('amount')->money('LKR'),
            TextColumn::make('paid_at')->date(),
            TextColumn::make('method')
        ])->recordActions([
            Action::make('edit')
                ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
        ])->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPayment::route('/'),
            'create' => Pages\CreatePayment::route('/create'),
            'edit' => Pages\EditPayment::route('/{record}/edit'),
        ];
    }
}
