<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id(); $table->string('name'); $table->text('description')->nullable();
            $table->decimal('price',12,2)->default(0); $table->decimal('tax_rate',5,2)->default(0);
            $table->boolean('is_recurring')->default(false); $table->string('recurring_interval')->nullable();
            $table->boolean('is_active')->default(true); $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('services');
    }
};
