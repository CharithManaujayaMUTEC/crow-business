<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class QuotationItem extends Model
{
    protected $fillable = ['quotation_id','item_type','item_id','description','quantity','unit_price','tax_rate','total'];
    protected $casts = ['quantity'=>'decimal:2','unit_price'=>'decimal:2','tax_rate'=>'decimal:2','total'=>'decimal:2'];
    public function quotation(): BelongsTo { return $this->belongsTo(Quotation::class); }
}
