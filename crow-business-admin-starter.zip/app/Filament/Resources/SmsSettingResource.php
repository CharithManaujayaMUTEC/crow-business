<?php

namespace App\Filament\Resources;

use App\Models\SmsSetting;
use Filament\Resources\Resource;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;

class SmsSettingResource extends Resource
{
    protected static ?string $model = SmsSetting::class;
    protected static ?string $navigationLabel = 'SMS Settings';
    protected static ?string $modelLabel = 'SMS Setting';
    protected static ?string $pluralModelLabel = 'SMS Settings';

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            Toggle::make('enabled')->label('Enable SMS sending'),
            TextInput::make('api_url')->label('API URL'),
            TextInput::make('api_user_id')->label('API User ID'),
            TextInput::make('api_key')->password()->revealable()->label('API Key'),
            TextInput::make('sender_id')->default('Crow.lk'),
            TextInput::make('country_code')->default('94')->helperText('Sri Lanka default: 94')
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            IconColumn::make('enabled')->boolean(),
            TextColumn::make('api_user_id'),
            TextColumn::make('sender_id'),
            TextColumn::make('country_code')
        ])->recordActions([
            Action::make('edit')
                ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
        ])->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSmsSetting::route('/'),
            'create' => Pages\CreateSmsSetting::route('/create'),
            'edit' => Pages\EditSmsSetting::route('/{record}/edit'),
        ];
    }
}
