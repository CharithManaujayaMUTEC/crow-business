<?php

namespace App\Filament\Resources;

use App\Models\Service;
use Filament\Resources\Resource;
use Filament\Actions\Action;
use Filament\Schemas\Schema;
use Filament\Tables\Table;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\FileUpload;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\IconColumn;

class ServiceResource extends Resource
{
    protected static ?string $model = Service::class;
    protected static ?string $navigationLabel = 'Services';
    protected static ?string $modelLabel = 'Service';
    protected static ?string $pluralModelLabel = 'Services';

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('name')->required(),
            Textarea::make('description')->columnSpanFull(),
            TextInput::make('price')->numeric()->prefix('LKR')->required(),
            TextInput::make('tax_rate')->numeric()->default(0),
            Toggle::make('is_recurring')->default(false),
            Select::make('recurring_interval')->options(['monthly'=>'Monthly','yearly'=>'Yearly'])->visible(fn ($get) => $get('is_recurring')),
            Toggle::make('is_active')->default(true)
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->searchable()->sortable(),
            TextColumn::make('price')->money('LKR'),
            IconColumn::make('is_recurring')->boolean(),
            IconColumn::make('is_active')->boolean()
        ])->recordActions([
            Action::make('edit')
                ->url(fn ($record) => static::getUrl('edit', ['record' => $record])),
        ])->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListService::route('/'),
            'create' => Pages\CreateService::route('/create'),
            'edit' => Pages\EditService::route('/{record}/edit'),
        ];
    }
}
